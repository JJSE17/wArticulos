﻿namespace wArticuloTipo
{
    partial class frmArticulo
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblIva = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.txtIva = new System.Windows.Forms.TextBox();
            this.rdbTipo4 = new System.Windows.Forms.RadioButton();
            this.rdbTipo7 = new System.Windows.Forms.RadioButton();
            this.rdbTipo16 = new System.Windows.Forms.RadioButton();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(352, 39);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(121, 29);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Articulos:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(282, 192);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(59, 16);
            this.lblNombre.TabIndex = 1;
            this.lblNombre.Text = "Nombre:";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Location = new System.Drawing.Point(282, 246);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(49, 16);
            this.lblPrecio.TabIndex = 2;
            this.lblPrecio.Text = "Precio:";
            // 
            // lblIva
            // 
            this.lblIva.AutoSize = true;
            this.lblIva.Location = new System.Drawing.Point(282, 304);
            this.lblIva.Name = "lblIva";
            this.lblIva.Size = new System.Drawing.Size(28, 16);
            this.lblIva.TabIndex = 3;
            this.lblIva.Text = "Iva:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(398, 192);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.ReadOnly = true;
            this.txtNombre.Size = new System.Drawing.Size(100, 22);
            this.txtNombre.TabIndex = 4;
            // 
            // txtPrecio
            // 
            this.txtPrecio.Location = new System.Drawing.Point(398, 240);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.ReadOnly = true;
            this.txtPrecio.Size = new System.Drawing.Size(100, 22);
            this.txtPrecio.TabIndex = 5;
            // 
            // txtIva
            // 
            this.txtIva.Location = new System.Drawing.Point(398, 301);
            this.txtIva.Name = "txtIva";
            this.txtIva.ReadOnly = true;
            this.txtIva.Size = new System.Drawing.Size(100, 22);
            this.txtIva.TabIndex = 6;
            // 
            // rdbTipo4
            // 
            this.rdbTipo4.AutoSize = true;
            this.rdbTipo4.Location = new System.Drawing.Point(206, 100);
            this.rdbTipo4.Name = "rdbTipo4";
            this.rdbTipo4.Size = new System.Drawing.Size(66, 20);
            this.rdbTipo4.TabIndex = 7;
            this.rdbTipo4.TabStop = true;
            this.rdbTipo4.Text = "Tipo 4";
            this.rdbTipo4.UseVisualStyleBackColor = true;
            this.rdbTipo4.CheckedChanged += new System.EventHandler(this.rdbTipo4_CheckedChanged);
            // 
            // rdbTipo7
            // 
            this.rdbTipo7.AutoSize = true;
            this.rdbTipo7.Location = new System.Drawing.Point(344, 100);
            this.rdbTipo7.Name = "rdbTipo7";
            this.rdbTipo7.Size = new System.Drawing.Size(66, 20);
            this.rdbTipo7.TabIndex = 8;
            this.rdbTipo7.TabStop = true;
            this.rdbTipo7.Text = "Tipo 7";
            this.rdbTipo7.UseVisualStyleBackColor = true;
            this.rdbTipo7.CheckedChanged += new System.EventHandler(this.rdbTipo7_CheckedChanged);
            // 
            // rdbTipo16
            // 
            this.rdbTipo16.AutoSize = true;
            this.rdbTipo16.Location = new System.Drawing.Point(533, 100);
            this.rdbTipo16.Name = "rdbTipo16";
            this.rdbTipo16.Size = new System.Drawing.Size(73, 20);
            this.rdbTipo16.TabIndex = 9;
            this.rdbTipo16.TabStop = true;
            this.rdbTipo16.Text = "Tipo 16";
            this.rdbTipo16.UseVisualStyleBackColor = true;
            this.rdbTipo16.CheckedChanged += new System.EventHandler(this.rdbTipo16_CheckedChanged);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(398, 355);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(90, 37);
            this.btnLimpiar.TabIndex = 10;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // frmArticulo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.rdbTipo16);
            this.Controls.Add(this.rdbTipo7);
            this.Controls.Add(this.rdbTipo4);
            this.Controls.Add(this.txtIva);
            this.Controls.Add(this.txtPrecio);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblIva);
            this.Controls.Add(this.lblPrecio);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblTitulo);
            this.Name = "frmArticulo";
            this.Text = "Articulos";
            this.Load += new System.EventHandler(this.frmArticulo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblIva;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.TextBox txtIva;
        private System.Windows.Forms.RadioButton rdbTipo4;
        private System.Windows.Forms.RadioButton rdbTipo7;
        private System.Windows.Forms.RadioButton rdbTipo16;
        private System.Windows.Forms.Button btnLimpiar;
    }
}


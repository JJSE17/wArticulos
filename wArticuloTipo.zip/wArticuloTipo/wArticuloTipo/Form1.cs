﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// summary   
/// Fecha: 22/03/2023
/// Integrantes: Juan Manuel Torres Alvarez / Juan Jose Soto Echavarria / Alexis Knight Wilfer
/// Descripcion: pasar trabajo de clases abstractas a Windows Forms
/// summary


namespace wArticuloTipo
{
    public partial class frmArticulo : Form
    {
        public frmArticulo()
        {
            InitializeComponent();
        }

        private void frmArticulo_Load(object sender, EventArgs e)
        {
            rdbTipo4.Checked = false;
            rdbTipo7.Checked = false;
            rdbTipo16.Checked = false;
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            rdbTipo4.Checked = false;
            rdbTipo7.Checked = false;
            rdbTipo16.Checked = false;

            txtIva.Text = ("");
            txtNombre.Text = ("");
            txtPrecio.Text = ("");
        }

        private void rdbTipo4_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rdbTipo4.Checked)
                {
                    clsTipo4 arepas = new clsTipo4("Arepas", 3000);
                    arepas.ObtenerNombre();
                    txtNombre.Text = (arepas.Nombre);
                    txtPrecio.Text = (Convert.ToString(arepas.Precio));
                    txtIva.Text = (Convert.ToString(arepas.ParteIva()));
                }
            }
            catch
            {
                MessageBox.Show("");
            }
        }

        private void rdbTipo7_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rdbTipo7.Checked)
                {
                    clsTipo7 panela = new clsTipo7("Panela", 2000);
                    panela.ObtenerNombre();
                    txtNombre.Text = (panela.Nombre);
                    txtPrecio.Text = (Convert.ToString(panela.Precio));
                    txtIva.Text = (Convert.ToString(panela.ParteIva()));
                }
            }
            catch
            {
                MessageBox.Show("");
            }
        }

        private void rdbTipo16_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rdbTipo16.Checked)
                {
                    clsTipo16 leche = new clsTipo16("Leche", 4200);
                    leche.ObtenerNombre();
                    txtNombre.Text = (leche.Nombre);
                    txtPrecio.Text = (Convert.ToString(leche.Precio));
                    txtIva.Text = (Convert.ToString(leche.ParteIva()));
                }
            }
            catch
            {
                MessageBox.Show("");
            }
        }
    }
}

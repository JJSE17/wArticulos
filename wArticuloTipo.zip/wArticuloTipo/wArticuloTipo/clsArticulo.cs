﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wArticuloTipo
{
    abstract class clsArticulo
    {
        public string Nombre { get; set; }
        public double Precio { get; set; }

        public clsArticulo(string nombre, double precio)
        {
            Nombre = nombre;
            Precio = precio;
        }

        public abstract double DarPrecio();
        public abstract double ParteIva();
        public abstract double ObtenerTipo();
        public abstract void ObtenerNombre();
    }
}

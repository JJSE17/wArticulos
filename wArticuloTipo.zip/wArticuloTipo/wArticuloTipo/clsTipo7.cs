﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using wArticuloTipo;

namespace wArticuloTipo
{
    class clsTipo7 : clsArticulo
    {
        public double Tipo = 7;
        public double Iva;
        public clsTipo7(string nombre, double precio)
            : base(nombre, precio)
        {
            Nombre = nombre;
            Precio = precio;
        }
        public override double ParteIva()
        //iva de colombia actual
        {
            Iva = (Precio * 19) / 100;
            return Iva;
        }
        public override void ObtenerNombre()
        {
            Console.WriteLine("Articulo: ");
        }


        public override double DarPrecio()
        {
            return Precio = Precio;
        }

        public override double ObtenerTipo()
        {
            return Tipo;
        }
    }
}